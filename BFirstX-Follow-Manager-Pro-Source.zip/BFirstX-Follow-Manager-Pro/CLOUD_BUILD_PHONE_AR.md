## بناء APK من الهاتف عبر GitHub

1. أنشئ مستودعًا جديدًا في GitHub.
2. فك ضغط هذا المشروع محليًا أو ارفع محتويات المشروع إلى المستودع.
3. تأكد من وجود `.github/workflows/build-apk.yml`.
4. افتح Actions.
5. انتظر اكتمال Build BFirstX Follow Manager Pro APK.
6. افتح آخر تشغيل أخضر.
7. من Artifacts نزّل `BFirstX-Follow-Manager-Pro-APK`.
8. فك ضغط Artifact وثبّت `BFirstX-Follow-Manager-Pro.apk`.
