package com.bfirstx.followmanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;

import org.json.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {

    private final ArrayList<AccountItem> accounts = new ArrayList<>();
    private LinearLayout listContainer;
    private TextView status, counter;
    private EditText search;
    private SharedPreferences prefs;
    private int queueIndex = 0;
    private ArrayList<AccountItem> currentQueue = new ArrayList<>();

    static class AccountItem {
        String username;
        boolean selected;
        String state = "pending"; // pending, done, skipped

        AccountItem(String username) {
            this.username = normalize(username);
        }
    }

    static String normalize(String s) {
        if (s == null) return "";
        s = s.trim();
        while (s.startsWith("@")) s = s.substring(1);
        s = s.replaceAll("[^A-Za-z0-9._]", "");
        return s;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("bfirstx_follow_manager", MODE_PRIVATE);
        buildUi();
        loadSaved();
        renderList("");
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView title(String text, int sp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setPadding(dp(8), dp(8), dp(8), dp(8));
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(16, 24, 39));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(18), dp(14), dp(30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        TextView appTitle = title("BFirstX Follow Manager Pro", 26);
        appTitle.setGravity(Gravity.CENTER);
        appTitle.setTypeface(null, 1);
        root.addView(appTitle);

        TextView desc = title(
            "إدارة دقيقة لقائمة المتابعة بدون Accessibility وبدون حفظ كلمة المرور. " +
            "استورد قائمة Following من ملف Instagram أو أضف الأسماء يدويًا، ثم اختر من تريد إلغاء متابعته وابدأ طابورًا منظّمًا.", 15);
        desc.setTextColor(Color.rgb(167,176,192));
        desc.setGravity(Gravity.CENTER);
        root.addView(desc);

        LinearLayout importRow = new LinearLayout(this);
        importRow.setOrientation(LinearLayout.HORIZONTAL);
        importRow.setGravity(Gravity.CENTER);
        Button importBtn = button("استيراد ملف Instagram");
        Button addBtn = button("+ إضافة اسم");
        importRow.addView(importBtn, new LinearLayout.LayoutParams(0, dp(54), 1));
        importRow.addView(addBtn, new LinearLayout.LayoutParams(0, dp(54), 1));
        root.addView(importRow);

        search = new EditText(this);
        search.setHint("بحث داخل القائمة...");
        search.setSingleLine(true);
        search.setTextColor(Color.BLACK);
        search.setHintTextColor(Color.DKGRAY);
        search.setBackgroundColor(Color.WHITE);
        search.setPadding(dp(12),0,dp(12),0);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(54));
        sp.setMargins(0, dp(10), 0, dp(8));
        root.addView(search, sp);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        Button all = button("تحديد الكل");
        Button none = button("إلغاء التحديد");
        Button clearDone = button("إخفاء المنتهي");
        tools.addView(all, new LinearLayout.LayoutParams(0, dp(50), 1));
        tools.addView(none, new LinearLayout.LayoutParams(0, dp(50), 1));
        tools.addView(clearDone, new LinearLayout.LayoutParams(0, dp(50), 1));
        root.addView(tools);

        counter = title("0 حساب", 15);
        counter.setTextColor(Color.rgb(67,215,165));
        root.addView(counter);

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(listContainer);

        Button start = button("بدء طابور الإزالة المختار");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(58));
        bp.setMargins(0, dp(12), 0, dp(6));
        root.addView(start, bp);

        status = title("جاهز.", 14);
        status.setTextColor(Color.rgb(167,176,192));
        root.addView(status);

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        Button instagram = button("فتح Instagram");
        Button browser = button("فتح الحساب بالمتصفح");
        quick.addView(instagram, new LinearLayout.LayoutParams(0, dp(52), 1));
        quick.addView(browser, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(quick);

        TextView note = title(
            "ملاحظة: Instagram لا يوفر API رسميًا لإلغاء المتابعة من تطبيق خارجي. " +
            "لهذا التطبيق لا ينفذ ضغط زر Unfollow بالنيابة عنك؛ أنت تؤكد العملية داخل Instagram. " +
            "بهذا نتجنب صلاحيات التحكم الحساسة وتحذيرات Play Protect.", 13);
        note.setTextColor(Color.rgb(167,176,192));
        root.addView(note);

        setContentView(scroll);

        importBtn.setOnClickListener(v -> openImporter());
        addBtn.setOnClickListener(v -> addManual());
        all.setOnClickListener(v -> {
            for (AccountItem a : accounts) if (!"done".equals(a.state)) a.selected = true;
            save(); renderList(search.getText().toString());
        });
        none.setOnClickListener(v -> {
            for (AccountItem a : accounts) a.selected = false;
            save(); renderList(search.getText().toString());
        });
        clearDone.setOnClickListener(v -> {
            accounts.removeIf(a -> "done".equals(a.state));
            save(); renderList(search.getText().toString());
        });
        start.setOnClickListener(v -> beginQueue());
        instagram.setOnClickListener(v -> launchInstagram());
        browser.setOnClickListener(v -> {
            AccountItem a = firstSelectedOrFirst();
            if (a != null) openBrowserProfile(a.username);
        });

        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ renderList(s.toString()); }
            public void afterTextChanged(android.text.Editable e){}
        });
    }

    private void openImporter() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json","text/html","text/plain"});
        startActivityForResult(i, 42);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 42 && result == RESULT_OK && data != null && data.getData() != null) {
            try {
                String text = readAll(data.getData());
                LinkedHashSet<String> found = new LinkedHashSet<>();
                parseInstagramExport(text, found);
                int added = 0;
                for (String u : found) {
                    if (u.isEmpty() || containsUser(u)) continue;
                    accounts.add(new AccountItem(u));
                    added++;
                }
                save();
                renderList(search.getText().toString());
                status.setText("تم استيراد " + added + " حسابًا.");
            } catch (Exception e) {
                status.setText("تعذر قراءة الملف: " + e.getMessage());
            }
        }
    }

    private String readAll(Uri uri) throws IOException {
        InputStream in = getContentResolver().openInputStream(uri);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf,0,n);
        in.close();
        return out.toString("UTF-8");
    }

    private void parseInstagramExport(String text, Set<String> out) {
        String trimmed = text.trim();
        try {
            if (trimmed.startsWith("{")) {
                walkJson(new JSONObject(trimmed), out);
                return;
            }
            if (trimmed.startsWith("[")) {
                walkJson(new JSONArray(trimmed), out);
                return;
            }
        } catch (Exception ignored) {}

        Pattern p = Pattern.compile("instagram\\.com/([A-Za-z0-9._]{1,30})", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(text);
        while (m.find()) out.add(normalize(m.group(1)));

        Pattern at = Pattern.compile("@([A-Za-z0-9._]{1,30})");
        Matcher m2 = at.matcher(text);
        while (m2.find()) out.add(normalize(m2.group(1)));
    }

    private void walkJson(Object node, Set<String> out) throws JSONException {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                Object v = o.get(k);
                if ("value".equals(k) && v instanceof String) {
                    String s = normalize((String)v);
                    if (s.matches("[A-Za-z0-9._]{1,30}")) out.add(s);
                }
                if ("href".equals(k) && v instanceof String) {
                    Matcher m = Pattern.compile("instagram\\.com/([A-Za-z0-9._]{1,30})", Pattern.CASE_INSENSITIVE)
                            .matcher((String)v);
                    if (m.find()) out.add(normalize(m.group(1)));
                }
                walkJson(v, out);
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i=0;i<a.length();i++) walkJson(a.get(i), out);
        }
    }

    private boolean containsUser(String u) {
        for (AccountItem a : accounts) if (a.username.equalsIgnoreCase(u)) return true;
        return false;
    }

    private void addManual() {
        EditText input = new EditText(this);
        input.setHint("username بدون @");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this)
            .setTitle("إضافة حساب")
            .setView(input)
            .setPositiveButton("إضافة", (d,w) -> {
                String u = normalize(input.getText().toString());
                if (!u.isEmpty() && !containsUser(u)) {
                    accounts.add(new AccountItem(u));
                    save();
                    renderList(search.getText().toString());
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void renderList(String filter) {
        listContainer.removeAllViews();
        String f = normalize(filter).toLowerCase(Locale.ROOT);
        int shown = 0, selected = 0, done = 0;

        for (AccountItem a : accounts) {
            if (!f.isEmpty() && !a.username.toLowerCase(Locale.ROOT).contains(f)) continue;
            shown++;
            if (a.selected) selected++;
            if ("done".equals(a.state)) done++;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4), dp(4), dp(4), dp(4));

            CheckBox cb = new CheckBox(this);
            cb.setChecked(a.selected);
            cb.setOnCheckedChangeListener((b,c) -> { a.selected = c; save(); updateCounter(); });

            TextView name = title("@" + a.username, 16);
            if ("done".equals(a.state)) name.setTextColor(Color.rgb(67,215,165));
            else if ("skipped".equals(a.state)) name.setTextColor(Color.rgb(232,93,117));
            else name.setTextColor(Color.WHITE);

            Button open = button("فتح");
            open.setOnClickListener(v -> openBest(a.username));

            row.addView(cb, new LinearLayout.LayoutParams(dp(48), dp(50)));
            row.addView(name, new LinearLayout.LayoutParams(0, dp(54), 1));
            row.addView(open, new LinearLayout.LayoutParams(dp(80), dp(50)));
            listContainer.addView(row);
        }
        updateCounter();
    }

    private void updateCounter() {
        int sel = 0, done = 0;
        for (AccountItem a : accounts) {
            if (a.selected) sel++;
            if ("done".equals(a.state)) done++;
        }
        counter.setText("الإجمالي: " + accounts.size() + " | المحدد: " + sel + " | المنتهي: " + done);
    }

    private void beginQueue() {
        currentQueue.clear();
        for (AccountItem a : accounts) if (a.selected && !"done".equals(a.state)) currentQueue.add(a);
        queueIndex = 0;
        if (currentQueue.isEmpty()) {
            status.setText("حدد حسابًا واحدًا على الأقل.");
            return;
        }
        showQueueDialog();
    }

    private void showQueueDialog() {
        if (queueIndex >= currentQueue.size()) {
            status.setText("اكتمل الطابور.");
            save(); renderList(search.getText().toString());
            return;
        }

        AccountItem a = currentQueue.get(queueIndex);
        String msg = "الحساب " + (queueIndex+1) + " من " + currentQueue.size() +
                "\n@" + a.username +
                "\n\nافتح الحساب، ألغِ المتابعة داخل Instagram، ثم ارجع واضغط «تم».";

        new AlertDialog.Builder(this)
            .setTitle("طابور الإزالة")
            .setMessage(msg)
            .setPositiveButton("فتح الحساب", (d,w) -> {
                copyUsername(a.username);
                openBest(a.username);
            })
            .setNeutralButton("تم", (d,w) -> {
                a.state = "done";
                a.selected = false;
                queueIndex++;
                save();
                showQueueDialog();
            })
            .setNegativeButton("تخطي", (d,w) -> {
                a.state = "skipped";
                queueIndex++;
                save();
                showQueueDialog();
            })
            .show();
    }

    private void openBest(String username) {
        copyUsername(username);

        // 1) Browser profile is the most deterministic destination.
        try {
            Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/" + username + "/"));
            startActivity(browser);
            status.setText("تم نسخ @" + username + " وفتح صفحة الحساب.");
            return;
        } catch (Exception ignored) {}

        // 2) Fallback to Instagram app home with username already copied.
        launchInstagram();
        status.setText("تم نسخ @" + username + ". افتح البحث والصقه داخل Instagram.");
    }

    private void openBrowserProfile(String username) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/" + username + "/"));
            startActivity(i);
            copyUsername(username);
            status.setText("تم فتح @" + username + " في المتصفح ونسخ الاسم.");
        } catch (Exception e) {
            status.setText("تعذر فتح المتصفح.");
        }
    }

    private void launchInstagram() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.instagram.android");
            if (i != null) {
                startActivity(i);
                return;
            }
        } catch (Exception ignored) {}
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/")));
        } catch (Exception ignored) {}
    }

    private void copyUsername(String username) {
        android.content.ClipboardManager cm =
            (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Instagram username", username));
    }

    private AccountItem firstSelectedOrFirst() {
        for (AccountItem a : accounts) if (a.selected) return a;
        return accounts.isEmpty() ? null : accounts.get(0);
    }

    private void save() {
        JSONArray arr = new JSONArray();
        try {
            for (AccountItem a : accounts) {
                JSONObject o = new JSONObject();
                o.put("username", a.username);
                o.put("selected", a.selected);
                o.put("state", a.state);
                arr.put(o);
            }
        } catch (JSONException ignored) {}
        prefs.edit().putString("accounts", arr.toString()).apply();
    }

    private void loadSaved() {
        accounts.clear();
        String s = prefs.getString("accounts", "[]");
        try {
            JSONArray arr = new JSONArray(s);
            for (int i=0;i<arr.length();i++) {
                JSONObject o = arr.getJSONObject(i);
                AccountItem a = new AccountItem(o.optString("username"));
                a.selected = o.optBoolean("selected", false);
                a.state = o.optString("state", "pending");
                if (!a.username.isEmpty()) accounts.add(a);
            }
        } catch (Exception ignored) {}
    }
}
